package ch.walica.a43_temp261026_4tp1_sharedprefs;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private LinearLayout main;
    private EditText etName;
    private Button btnSave, btnClear;
    private TextView tvEnteredText, tvSavedText;
    private SwitchCompat mySwitch;

    private String enteredText = "";
    private boolean isGray = false;

    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        main = findViewById(R.id.main);
        etName = findViewById(R.id.etName);
        btnSave = findViewById(R.id.btnSave);
        btnClear = findViewById(R.id.btnClear);
        tvEnteredText = findViewById(R.id.tvEnteredText);
        tvSavedText = findViewById(R.id.tvSavedText);
        mySwitch = findViewById(R.id.mySwitch);

        sharedPreferences = getSharedPreferences("shared_prefs_1", MODE_PRIVATE);

        enteredText = sharedPreferences.getString("name_key", "");
        isGray = sharedPreferences.getBoolean("gray_key", false);
        mySwitch.setChecked(isGray);

        if(isGray) {
            main.setBackgroundColor(getColor(R.color.gray));
        } else {
            main.setBackgroundColor(getColor(R.color.white));
        }


        tvSavedText.setText(enteredText);

        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {

            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                enteredText = charSequence.toString();
                tvEnteredText.setText(enteredText);
            }
        });

        btnSave.setOnClickListener(view -> {
            tvSavedText.setText(enteredText);
            sharedPreferences.edit().putString("name_key", enteredText).apply();
            Toast.makeText(this, "Imie zostało zapisane", Toast.LENGTH_SHORT).show();
        });

        mySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull CompoundButton compoundButton, boolean b) {
                isGray = b;
                if(isGray) {
                    main.setBackgroundColor(getColor(R.color.gray));
                } else {
                    main.setBackgroundColor(getColor(R.color.white));
                }
                sharedPreferences.edit().putBoolean("gray_key", isGray).apply();
            }
        });

    }
}