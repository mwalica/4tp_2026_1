package ch.walica.a28_temp51026_4tp1_fragment_przesylanie;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.material.appbar.MaterialToolbar;

public class ResultFragment extends Fragment {

    private MaterialToolbar materialToolbar;
    private TextView tvResult;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_result, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        materialToolbar = view.findViewById(R.id.topAppBarResult);
        tvResult = view.findViewById(R.id.tvResult);

        materialToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new HomeFragment()).commit();
            }
        });

        if (getArguments() != null) {
            String name = getArguments().getString("name_key");
            int age = getArguments().getInt("age_key");
            tvResult.setText("Hello " + name + " " + age);
        }
    }
}