package ch.walica.a45_temp21126_4tp1_zadanie_shared_list;

import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private RadioGroup radioGroup;
    private ListView listView;
    private TextView tvResult;
    private Button btnClear, btnClose;
    private int  selectedRadioButtonId;

    private String[] languages = {"JavaScript", "TypeScript", "PHP", "Python", "Java"};
    private int counter = 0;
    private boolean isRed = true;

    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        radioGroup = findViewById(R.id.radioGroup);
        listView = findViewById(R.id.listView);
        tvResult = findViewById(R.id.tvResult);
        btnClear = findViewById(R.id.btnClear);
        btnClose = findViewById(R.id.btnClose);
        sharedPreferences = getSharedPreferences("Shared_prefs", MODE_PRIVATE);


        isRed = sharedPreferences.getBoolean("color_key", true);
        counter = sharedPreferences.getInt("counter_key", 0);

        tvResult.setText(String.valueOf(counter));

        if(isRed) {
            tvResult.setTextColor(getColor(R.color.red));
            listView.setDivider(new ColorDrawable(ContextCompat.getColor(MainActivity.this, R.color.red)));
            listView.setDividerHeight(4);
            radioGroup.check(R.id.rbRed);
        } else {
            tvResult.setTextColor(getColor(R.color.blue));
            listView.setDivider(new ColorDrawable(ContextCompat.getColor(MainActivity.this, R.color.blue)));
            listView.setDividerHeight(4);
            radioGroup.check(R.id.rbBlue);
        }

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull RadioGroup radioGroup, int i) {
                selectedRadioButtonId = i;
                if(selectedRadioButtonId == R.id.rbRed) {
                    isRed = true;
                    tvResult.setTextColor(getColor(R.color.red));
                    listView.setDivider(new ColorDrawable(ContextCompat.getColor(MainActivity.this, R.color.red)));
                    listView.setDividerHeight(4);
                } else {
                    isRed = false;
                    tvResult.setTextColor(getColor(R.color.blue));
                    listView.setDivider(new ColorDrawable(ContextCompat.getColor(MainActivity.this, R.color.blue)));
                    listView.setDividerHeight(4);
                }

                sharedPreferences.edit().putBoolean("color_key", isRed).apply();
            }
        });

        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, languages);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                counter++;
                tvResult.setText(String.valueOf(counter));
                sharedPreferences.edit().putInt("counter_key", counter).apply();
            }
        });

        btnClose.setOnClickListener(view -> {
            finish();
        });

        btnClear.setOnClickListener(view -> {
            counter = 0;
            tvResult.setText(String.valueOf(counter));
            sharedPreferences.edit().clear().apply();
        });
    }
}