package ch.walica.a23_temp280926_4tp1_fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class BottomFragment extends Fragment {

    private Button btnAdd;
    private TextView tvResult;
    private int count = 0;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_bottom, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        btnAdd = view.findViewById(R.id.btnAdd);
        tvResult = view.findViewById(R.id.tvResult);
        tvResult.setText(String.valueOf(count));

        btnAdd.setOnClickListener(v -> {
            count++;
            tvResult.setText(String.valueOf(count));
        });
    }
}