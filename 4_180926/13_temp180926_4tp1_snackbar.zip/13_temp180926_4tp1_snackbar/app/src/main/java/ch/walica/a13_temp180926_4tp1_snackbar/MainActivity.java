package ch.walica.a13_temp180926_4tp1_snackbar;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    private View myView;
    private Button btnShow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        myView = findViewById(R.id.myView);
        btnShow = findViewById(R.id.btnShow);

        btnShow.setOnClickListener(view -> {
            Snackbar.make(btnShow, "Czy zmienić kolor?", Snackbar.LENGTH_LONG)
                    .setTextColor(Color.CYAN)
                    .setBackgroundTint(Color.rgb(0, 128, 255))
                    .setAnimationMode(Snackbar.ANIMATION_MODE_SLIDE)
                    .setAction("Tak", v -> {
                        myView.setBackgroundColor(Color.RED);
                    })
                    .setAnchorView(myView)
                    .show();
        });
    }
}