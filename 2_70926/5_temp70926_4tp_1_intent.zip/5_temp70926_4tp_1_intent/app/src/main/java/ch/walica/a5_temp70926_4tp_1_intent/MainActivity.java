package ch.walica.a5_temp70926_4tp_1_intent;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

import ch.walica.a5_temp70926_4tp_1_intent.model.User;

public class MainActivity extends AppCompatActivity {
    private EditText etName;
    private Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etName = findViewById(R.id.etName);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(view -> {
            String name = etName.getText().toString().trim();
            int age = new Random().nextInt(81) + 18;
            User user = new User(name, age);
            Intent intent = new Intent(MainActivity.this, ResultActivity.class);
//            intent.putExtra("key_name", name);
//            intent.putExtra("key_age", age);
            intent.putExtra("key_user", user);
            startActivity(intent);
        });
    }
}