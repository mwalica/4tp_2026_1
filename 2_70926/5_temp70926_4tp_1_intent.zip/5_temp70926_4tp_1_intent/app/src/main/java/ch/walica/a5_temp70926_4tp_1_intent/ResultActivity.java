package ch.walica.a5_temp70926_4tp_1_intent;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import ch.walica.a5_temp70926_4tp_1_intent.model.User;

public class ResultActivity extends AppCompatActivity {

    private TextView tvResult;
    private Button btnBack;
    private String name;
    private int age;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_result);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvResult = findViewById(R.id.tvResult);
        btnBack = findViewById(R.id.btnBack);

//        if (getIntent().hasExtra("key_name") && getIntent().hasExtra("key_age")) {
//            name = getIntent().getStringExtra("key_name");
//            age = getIntent().getIntExtra("key_age", 0);
//            tvResult.setText(name + " " + age);
//        }

        if(getIntent().hasExtra("key_user")) {
            User user = (User) getIntent().getSerializableExtra("key_user");
            name = user.getName();
            age = user.getAge();
            tvResult.setText(name + " " + age);
        }

        btnBack.setOnClickListener(view -> {
            finish();
        });
    }
}