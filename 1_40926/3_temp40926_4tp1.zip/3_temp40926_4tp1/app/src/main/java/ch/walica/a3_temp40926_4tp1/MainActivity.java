package ch.walica.a3_temp40926_4tp1;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.NumberPicker;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.awt.font.NumericShaper;

public class MainActivity extends AppCompatActivity {

    private NumberPicker numberPicker;
    private TextView tvResult;
    int selectedNumber = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        numberPicker = findViewById(R.id.numberPicker);
        tvResult = findViewById(R.id.tvResult);

        numberPicker.setMaxValue(100);
        numberPicker.setMinValue(10);
        numberPicker.setValue(selectedNumber);

        tvResult.setText(String.valueOf(selectedNumber));

        numberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker numberPicker, int oldVal, int newVal) {
                selectedNumber = newVal;
                if (selectedNumber < 20) {
                    tvResult.setText(String.valueOf(selectedNumber));
                    tvResult.setTextColor(Color.BLACK);
                } else if (selectedNumber < 50) {
                    tvResult.setTextColor(getColor(R.color.black));
                    tvResult.setText(String.valueOf(selectedNumber *2));
                } else {
                    tvResult.setText(String.valueOf(selectedNumber *2));
                    tvResult.setTextColor(Color.rgb(255, 0, 0));
                }
            }
        });
    }
}