package ch.walica.a26_temp51026_4tp1_fragment;

import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;


public class SecondFragment extends Fragment {

    private RadioGroup radioGroup;
    private View myView;
    private int selectedId;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_second, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        radioGroup = view.findViewById(R.id.radioGroup);
        myView = view.findViewById(R.id.myView);

        selectedId = radioGroup.getCheckedRadioButtonId();

        if(selectedId == R.id.rbRed) {
            myView.setBackgroundColor(Color.RED);
        } else if(selectedId == R.id.rbBlue) {
            myView.setBackgroundColor(Color.BLUE);

        }

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull RadioGroup radioGroup, int i) {
                selectedId = i;
                if(selectedId == R.id.rbRed) {
                    myView.setBackgroundColor(Color.RED);
                } else if(selectedId == R.id.rbBlue) {
                    myView.setBackgroundColor(Color.BLUE);

                }

                RadioButton selectedRb = view.findViewById(i);
                Toast.makeText(requireContext(), "Zaznaczone: " + selectedRb.getText(), Toast.LENGTH_SHORT).show();
            }
        });

        myView.setOnClickListener(v -> {
            requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new FirstFragment()).commit();
        });
    }
}