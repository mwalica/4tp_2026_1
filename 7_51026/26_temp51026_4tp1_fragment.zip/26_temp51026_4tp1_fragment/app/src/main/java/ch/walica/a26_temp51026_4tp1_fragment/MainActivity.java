package ch.walica.a26_temp51026_4tp1_fragment;

import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class MainActivity extends AppCompatActivity {

    private Button btnSwitchFragment;
    private FragmentManager fragmentManager;
    boolean isFirst = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnSwitchFragment = findViewById(R.id.btnSwitchFragment);
        fragmentManager = getSupportFragmentManager();

        Fragment firstFragment = new FirstFragment();
        Fragment secondFragment = new SecondFragment();

        fragmentManager.beginTransaction().add(R.id.fragmentContainerView, firstFragment).commit();

        btnSwitchFragment.setOnClickListener(view -> {
            if(isFirst) {
                isFirst = false;
                fragmentManager.beginTransaction().replace(R.id.fragmentContainerView, secondFragment).commit();
                btnSwitchFragment.setText("Do pierwszego");
            } else {
                isFirst = true;
                fragmentManager.beginTransaction().replace(R.id.fragmentContainerView, firstFragment).commit();
                btnSwitchFragment.setText("Do drugiego");
            }
        });
    }
}